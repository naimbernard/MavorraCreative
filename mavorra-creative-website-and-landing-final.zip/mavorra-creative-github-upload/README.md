# Mavorra Creative Website

This is the complete Vercel-ready website for Mavorra Creative.

## Included

- Main website homepage
- Separate landing page with form at `/start-project`
- Approved logo included in `/public/logo.png`
- Google Sheets lead capture API at `/api/lead`
- Mobile, tablet and desktop responsive styling
- Ready to upload to GitHub and import into Vercel

## Google Sheet columns

Create a Google Sheet tab called `Leads`.

Add these columns in row 1:

Date | Name | Email | Phone | Business Name | Marketing Type | Start Timeline | Project Details | Source

## Environment variables for Vercel

Add these inside Vercel Project Settings > Environment Variables:

GOOGLE_SHEETS_CLIENT_EMAIL  
GOOGLE_SHEETS_PRIVATE_KEY  
GOOGLE_SHEETS_SPREADSHEET_ID  
GOOGLE_SHEETS_SHEET_NAME

Use `Leads` for GOOGLE_SHEETS_SHEET_NAME.

## Local testing

npm install  
npm run dev

Then open:

http://localhost:3000

## Deploy

1. Upload this project folder to GitHub.
2. Import the GitHub repository into Vercel.
3. Add the Google Sheets environment variables.
4. Deploy.
5. Connect your GoDaddy domain in Vercel.
